#include "list.h"

DoubleList::pathElement::pathElement()
{
    next = 0;
    prev = 0;
    g = 0;
    h = 0;
    f = 0;
}

DoubleList::list::list()
{
    head = 0;
    nextList = 0;
    prevList = 0;
    tail = head;
    counter = 0;
}

DoubleList::list2d::list2d()
{
    listHead = 0;
    listTail = listHead;
    listCounter = 0;
}

void DoubleList::list::add_element(int elementType, int elementX, int elementY)
{
    pathElement * newElement = new pathElement;
    newElement->type = elementType;
    newElement->x = elementX;
    newElement->y = elementY;

    if (head == 0)
    {
        head = newElement;
        head->next = 0;
        tail = head;
        counter ++;
    }
    else
    {
        pathElement * temp = head;

        while (temp->next)
        {
            temp = temp->next;
        }
        newElement->next = 0;
        tail = newElement;
        temp->next = tail;
        tail->prev = temp;
        counter ++;
    }

}

void DoubleList::list::remove_last_element()
{
    if (counter == 0)
        return;

    if (counter == 1)
    {
        head = 0;
        tail = head;
        counter --;
    }
    else
    {
        pathElement * newLast = head, * last;

        last = newLast->next;
        while (last->next)
        {
            newLast = newLast->next;
            last = last->next;
        }
        delete last;
        newLast->next = 0;
        tail = newLast;
        counter --;
    }
}
void DoubleList::list::show_list(int howMany)
{
    if (counter == 0)
    {
        qDebug() << "NO ELEMENTS";
        return;
    }
    int howFar;
    QString blad;
    if (howMany > counter)
    {
        howFar = counter;
        blad = "PODANO ZA DUZO WYRAZOW";
    }
    else
        howFar = howMany;

    pathElement * element = head;

    while (howFar > 0)
    {
        //qDebug() << element->x << "  " << element->y;
        qDebug() << element->type << "  x: " << element->x << "  y: " << element->y << "  f: " << element->f;
        element = element->next;
        howFar --;
    }
    if (blad.size() > 0)
        qDebug() << blad;

}

void DoubleList::list2d::add_list()
{
    list * newList = new list;

    if (listHead == 0)
    {
        listHead = newList;
        listHead->nextList = 0;
        listTail = listHead;
        listCounter ++;
    }
    else
    {
        list * tempList = listHead;

        while (tempList->nextList)
        {
            tempList = tempList->nextList;
        }
        newList->nextList = 0;
        tempList->nextList = newList;
        listTail = newList;
        listTail->prevList = tempList;
        listCounter ++;
    }
}

void DoubleList::list2d::create_lists(int quantity, list2d * nazwa)
{
    DoubleList::list2d * lista = nazwa;
    for (int i = 0; i < quantity; i++)
    {
        lista->add_list();
    }
}

void DoubleList::list2d::show_list_2d(int howMany)
{
    if (listCounter == 0)
    {
        qDebug() << "NO ELEMENTS";
        return;
    }
    int howFar;
    QString blad;
    if (howMany > listCounter)
    {
        howFar = listCounter;
        blad = "PODANO ZA DUZO LIST";
    }
    else
        howFar = howMany;

    list * list = listHead;

    while (howFar > 0)
    {
        //qDebug() << element->x << "  " << element->y;
        list->show_list(list->counter);
        list = list->nextList;
        howFar --;
    }
    if (blad.size() > 0)
        qDebug() << blad;

}

void DoubleList::list2d::show_all()
{
    list * list = listHead;
    for(int i = 0; i < listCounter; i++)
    {
        list->show_list(list->counter);
        list = list->nextList;
    }
}

int DoubleList::list2d::check_type(int x, int y, list2d * nazwa)
{
    if (x < 1 || y < 1 || x > 512 || y > 512)
        return 1;
    list * list = nazwa->listHead;
    for (int i = 0; i < y; i++)
    {
        list = list->nextList;
    }
    pathElement * element = list->head;
    for (int i = 0; i < x; i++)
    {
        element = element->next;
    }
    return element->type;
}
