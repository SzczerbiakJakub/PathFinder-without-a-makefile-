#include "algorithm.h"

Algorithm::Algorithm()
{
    QImage pathImage(512, 512, QImage::Format_ARGB32);
    pathImage.fill(qRgba(0,0,0,0));
}

double Algorithm::distance_between_points(int x1, int y1, int x2, int y2)
{
    /*int x = x2 - x1, y = y2 - y1;
    return abs(x)+abs(y);   */   //  MANHATTAN HEURISTIC

    int dx = abs(x1 - x2), dy = abs(y1 - y2), D = 2, D2 = 3;
    //double D2 = 1.41;                 //    D2 = sqrt(2) - NIEWYMIERNOSC BUGUJE ALGORYTM
                                      //    NIECH D = 2 I D2 = 3 - CALKOWITE LICZBY
    if (dx < dy)
        return D * (dx + dy) + (D2 - 2 * D) * dx;
    else
        return D * (dx + dy) + (D2 - 2 * D) * dy;  // DIAGONAL HEURISTIC

    //return sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1)); // EUCLIDEAN HEURISTIC
}

QPixmap Algorithm::create_path(QImage image)
{
    return QPixmap::fromImage(image);
}


void Algorithm::nearest_space_clockwise(DoubleList::pathElement * wall,
                                        DoubleList::list * succesors, DoubleList::list * elements/*, DoubleList::list2d * paths*/)
{
    int position = 1;
    DoubleList::pathElement * leftElement = 0, * rightElement = 0,
            * current = succesors->head, * previousElement;


    while (current != wall)     // OKRESLENIE, KTORA W KOLEJNOSCI JEST SCIANA (ELEMENTY STWORZONE ODWROTNIE DO WSKAZOWEK ZEGARA)
    {
        current = current->next;
        position ++;
    }

    qDebug() << "ŚCIANA NA POZYCJI: " << position;
    qDebug() << "KOORDY SCIANY: " << wall->x <<" "<<wall->y;

    for (int i = position; i < succesors->counter; i++)    // OD POZYCJI DO KONCA LISTY
    {
        previousElement = current;
        current = current->next;

        qDebug() << current->x <<" "<<current->y<<" "<<current->type;

        if (leftElement == 0)
        {
            if (current->type == 0 && previousElement->type == 1)
            {
                leftElement = current;
            }
        }
        if (rightElement == 0)
        {
            if (current->type == 1 && previousElement->type == 0)
            {
                rightElement = previousElement;
            }
        }
    }

    previousElement = current;
    current = succesors->head;

    for (int i = 0; i < position; i++)
    {
        qDebug() << current->x <<" "<<current->y<<" "<<current->type;

        if (leftElement == 0)
        {
            if (current->type == 0 && previousElement->type == 1)
            {
                leftElement = current;
            }
        }
        if (rightElement == 0)
        {
            if (current->type == 1 && previousElement->type == 0)
            {
                rightElement = previousElement;
            }
        }
        previousElement = current;
        current = current->next;
    }

    if (leftElement == 0)
    {
        current = wall;

        for (int i = position; i < succesors->counter; i++)    // OD POZYCJI DO KONCA LISTY
        {
            previousElement = current;
            current = current->next;

            qDebug() << current->x <<" "<<current->y<<" "<<current->type;

            if (leftElement == 0)
            {
                if (current->type == 2 && previousElement->type != 2)
                {
                    leftElement = current;
                }
            }
        }

        previousElement = current;
        current = succesors->head;

        for (int i = 0; i < position; i++)
        {
            qDebug() << current->x <<" "<<current->y<<" "<<current->type;

            if (leftElement == 0)
            {
                if (current->type == 2 && previousElement->type != 2)
                {
                    leftElement = current;
                }
            }
            previousElement = current;
            current = current->next;
        }
    }

    if (rightElement == 0)
    {
        current = wall;

        for (int i = position; i < succesors->counter; i++)    // OD POZYCJI DO KONCA LISTY
        {
            previousElement = current;
            current = current->next;

            qDebug() << current->x <<" "<<current->y<<" "<<current->type;

            if (rightElement == 0)
            {
                if (current->type != 2 && previousElement->type == 2)
                {
                    rightElement = previousElement;
                }
            }
        }

        previousElement = current;
        current = succesors->head;

        for (int i = 0; i < position; i++)
        {
            qDebug() << current->x <<" "<<current->y<<" "<<current->type;

            if (rightElement == 0)
            {
                if (current->type != 2 && previousElement->type == 2)
                {
                    rightElement = previousElement;
                }
            }
            previousElement = current;
            current = current->next;
        }
    }

    //      ZNAMY KOORDY LEWEGO I PRAWEGO, MOZNA DZIALAC DALEJ

    if (leftElement != 0 && rightElement != 0)
        elements->add_element(leftElement->type,leftElement->x,leftElement->y);

    if (rightElement != 0)
        elements->add_element(rightElement->type,rightElement->x,rightElement->y);

    elements->show_list(elements->counter);

    if (rightElement == leftElement)
        delete leftElement;
    else
    {
        delete leftElement;
        delete rightElement;
    }
}

bool Algorithm::build_path_element(int x1, int y1, int x2, int y2, int radius, DoubleList::list * possiblePath,
                                   DoubleList::list2d * list2d, DoubleList::list2d * paths, int mode)
{
    int wartoscF = possiblePath->tail->f, formerF = wartoscF, horizontal, vertical;
    bool firstSuccessorIsForbidden = false, choiceMade = false, isWall = false;

    DoubleList::pathElement * chosenElement, * successorElement, * forbiddenElement;
    DoubleList::list * forbiddenList = new DoubleList::list;

        DoubleList::list * succesorsList = new DoubleList::list;

    /*if (possiblePath->tail->type == 3)
    {
        qDebug() << "OSTATNI ELEMENT TEJ LISTY POWTÓRZYŁ SIĘ";
        return true;
    }   */

    for (int i = -radius; i < 2*radius; i+= radius)             //  8 NASTĘPCÓW BADANEGO ELEMENTU
        {
            succesorsList->add_element(list2d->check_type(x1-radius, y1+i, list2d), x1-radius, y1+i);
            succesorsList->tail->g = possiblePath->tail->g + Algorithm::distance_between_points(x1,y1,x1-radius,y1+i);
            succesorsList->tail->h = Algorithm::distance_between_points(x1-radius,y1+i,x2,y2);
            succesorsList->tail->f = succesorsList->tail->g + succesorsList->tail->h;

            forbiddenList = paths->listHead;

            while (forbiddenList != 0)
            {
                forbiddenElement = forbiddenList->head;
                while (forbiddenElement != 0)
                {
                    if (succesorsList->tail->x == forbiddenElement->x && succesorsList->tail->y == forbiddenElement->y)
                    {
                        succesorsList->tail->type = 2;
                        if (succesorsList->tail == succesorsList->head)
                        {
                            firstSuccessorIsForbidden = true;
                        }
                        else
                            succesorsList->tail->prev->type = 2;
                        //qDebug() << "WYKRYTO PRZESZKODE: " << succesorsList->tail->x << ", " << succesorsList->tail->y;
                    }
                    forbiddenElement = forbiddenElement->next;
                }
                forbiddenList = forbiddenList->nextList;
            }
        }

        succesorsList->add_element(list2d->check_type(x1, y1+radius, list2d), x1, y1+radius);
        succesorsList->tail->g = possiblePath->tail->g + Algorithm::distance_between_points(x1,y1,x1,y1+radius);
        succesorsList->tail->h = Algorithm::distance_between_points(x1,y1+radius,x2,y2);
        succesorsList->tail->f = succesorsList->tail->g + succesorsList->tail->h;

        forbiddenList = paths->listHead;
        while (forbiddenList != 0)
        {
            forbiddenElement = forbiddenList->head;
            while (forbiddenElement != 0)
            {
                if (succesorsList->tail->x == forbiddenElement->x && succesorsList->tail->y == forbiddenElement->y)
                {
                    succesorsList->tail->type = 2;
                    succesorsList->tail->prev->type = 2;
                    //qDebug() << "WYKRYTO PRZESZKODE: " << succesorsList->tail->x << ", " << succesorsList->tail->y;
                }
                forbiddenElement = forbiddenElement->next;
            }
            forbiddenList = forbiddenList->nextList;
        }

        for (int i = -radius; i < 2*radius; i+= radius)
        {
            succesorsList->add_element(list2d->check_type(x1+radius, y1-i, list2d), x1+radius, y1-i);
            succesorsList->tail->g = possiblePath->tail->g + Algorithm::distance_between_points(x1,y1,x1+radius,y1-i);
            succesorsList->tail->h = Algorithm::distance_between_points(x1+radius,y1-i,x2,y2);
            succesorsList->tail->f = succesorsList->tail->g + succesorsList->tail->h;

            forbiddenList = paths->listHead;
            while (forbiddenList != 0)
            {
                forbiddenElement = forbiddenList->head;
                while (forbiddenElement != 0)
                {
                    if (succesorsList->tail->x == forbiddenElement->x && succesorsList->tail->y == forbiddenElement->y)
                    {
                        succesorsList->tail->type = 2;
                        succesorsList->tail->prev->type = 2;
                        //qDebug() << "WYKRYTO PRZESZKODE: " << succesorsList->tail->x << ", " << succesorsList->tail->y;
                    }
                    forbiddenElement = forbiddenElement->next;
                }
                forbiddenList = forbiddenList->nextList;
            }
        }

        succesorsList->add_element(list2d->check_type(x1, y1-radius, list2d), x1, y1-radius);
        succesorsList->tail->g = possiblePath->tail->g + Algorithm::distance_between_points(x1,y1,x1,y1-radius);
        succesorsList->tail->h = Algorithm::distance_between_points(x1,y1-radius,x2,y2);
        succesorsList->tail->f = succesorsList->tail->g + succesorsList->tail->h;

        forbiddenList = paths->listHead;
        while (forbiddenList != 0)
        {
            forbiddenElement = forbiddenList->head;
            while (forbiddenElement != 0)
            {
                if (succesorsList->tail->x == forbiddenElement->x && succesorsList->tail->y == forbiddenElement->y)
                {
                    succesorsList->tail->type = 2;
                    succesorsList->tail->prev->type = 2;
                    //qDebug() << "WYKRYTO PRZESZKODE: " << succesorsList->tail->x << ", " << succesorsList->tail->y;
                }
                forbiddenElement = forbiddenElement->next;
            }
            forbiddenList = forbiddenList->nextList;
        }

        if (firstSuccessorIsForbidden == true)
            succesorsList->tail->type = 2;


        choiceMade = false;
        isWall = false;

        while (choiceMade == false)     //  DOPOKI NIE WYBRANO NASTEPCY TO NIE RUSZA DALEJ
        {
            DoubleList::list * chosenSuccessors = new DoubleList::list;     // LISTA WYBRANYCH NASTEPCOW

            while (chosenSuccessors->counter == 0 && isWall == false)
            {
                successorElement = succesorsList->head;
                for (int i = 0; i < 8; i++)
                {                      // WYBOR TYCH Z NAJMNIEJSZYM KOSZTEM (najkorzystniejszy wybor, uwzglednia ściany)
                    if (successorElement->f <= wartoscF && successorElement->f >= formerF)
                    {
                        if (successorElement->type == 1)  // WARUNEK NA SCIANE
                        {
                            isWall = true;
                            chosenElement = successorElement;
                        }
                        else if (successorElement->type == 0)       //  WARUNEK NA MOŻLIWY KROK
                        {
                            chosenSuccessors->add_element(successorElement->type,successorElement->x,
                                                          successorElement->y);
                            chosenSuccessors->tail->g = successorElement->g;
                            chosenSuccessors->tail->h = successorElement->h;
                            chosenSuccessors->tail->f = successorElement->f;


                        }
                    }
                    successorElement = successorElement->next;
                }


                if (chosenSuccessors->counter == 0 && isWall == false)
                    //  JEŚLI NIE MA ŚCIANY ANI KORZYSTNYCH KROKÓW - ZWIĘKSZYĆ AKCEPTOWALNE WARUNKI KORZYŚCI
                {
                    wartoscF ++;
                    formerF ++;
                }
            }

            if (isWall)     // PRZY WYBORZE ŚCIANY TRAKTUJEMY JĄ JAKO PRZESZKODE - IDZIEMY PO JEJ OBWODZIE,
                    //  AŻ NASTEPNYM KROKIEM NIE BĘDZIE ŚCIANA, MOŻE BYĆ KILKA ŚCIEŻEK - NALEŻY WYBRAĆ NAJLEPSZĄ
            {
                DoubleList::list * wallPathElements = new DoubleList::list;

                horizontal = chosenElement->x - possiblePath->tail->x;
                vertical = chosenElement->y - possiblePath->tail->y;

                qDebug() << "KIERUNEK: " << horizontal << "   " << vertical;
                successorElement = succesorsList->head;

                qDebug() << successorElement->type << " " << succesorsList->tail->type << " " << succesorsList->tail->prev->type;
                qDebug() << successorElement->next->type << " " << 9 << " " << succesorsList->tail->prev->prev->type;
                qDebug() << successorElement->next->next->type << " " << successorElement->next->next->next->type << " " << successorElement->next->next->next->next->type;


                nearest_space_clockwise(chosenElement, succesorsList, wallPathElements);


                DoubleList::pathElement * leftWallPathElement = wallPathElements->head;
                DoubleList::pathElement * rightWallPathElement = leftWallPathElement->next;


                if (mode == 0)
                {
                    choiceMade = true;
                    possiblePath->add_element(leftWallPathElement->type, leftWallPathElement->x, leftWallPathElement->y);
                    possiblePath->tail->g = possiblePath->tail->prev->g + Algorithm::distance_between_points(x1,y1,possiblePath->tail->x,possiblePath->tail->y);
                    possiblePath->tail->h = Algorithm::distance_between_points(possiblePath->tail->x,possiblePath->tail->y,x2,y2);
                    possiblePath->tail->f = possiblePath->tail->g + possiblePath->tail->h;
                }
                else if (mode == 1)
                {
                    choiceMade = true;
                    possiblePath->add_element(rightWallPathElement->type, rightWallPathElement->x, rightWallPathElement->y);
                    possiblePath->tail->g = possiblePath->tail->prev->g + Algorithm::distance_between_points(x1,y1,possiblePath->tail->x,possiblePath->tail->y);
                    possiblePath->tail->h = Algorithm::distance_between_points(possiblePath->tail->x,possiblePath->tail->y,x2,y2);
                    possiblePath->tail->f = possiblePath->tail->g + possiblePath->tail->h;
                }

                delete wallPathElements;

            }
            else            //      JEŻELI NIE WYBRANO ŚCIANY, TO POSTĘPUJEMY TAK JAK ZWYKLE
            {
                qDebug() << chosenSuccessors->counter;

                chosenSuccessors->show_list(chosenSuccessors->counter);

                successorElement = chosenSuccessors->head;

                if (successorElement->type == 2)
                {
                    //possiblePath->tail->type = 3;
                }
                else
                {
                    choiceMade = true;
                    possiblePath->add_element(successorElement->type, successorElement->x, successorElement->y);
                    possiblePath->tail->g = successorElement->g;
                    possiblePath->tail->h = successorElement->h;
                    possiblePath->tail->f = successorElement->f;


                }
            }

            if (choiceMade == false)
            {
                formerF = wartoscF;
                wartoscF ++;
            }

            delete chosenSuccessors;

        }       //  UPEWNIASZ SIE, ZE WYBRALES JAKIS ELEMENT

        qDebug() << possiblePath->counter << " KROK (Fmin: " << possiblePath->tail->f << " ), x: " << possiblePath->tail->x << ", y: " << possiblePath->tail->y;

        wartoscF = possiblePath->tail->g + possiblePath->tail->h;
        formerF = wartoscF;

        delete succesorsList;

        if (isWall == true)
            return true;

        else if (choiceMade == true)
        {
            return false;
        }

        return false;
}




DoubleList::list2d * Algorithm::find_ways(int x1, int y1, int x2, int y2, int radius, DoubleList::list2d * list2d, DoubleList::list2d * paths)
{

    //  ZASADY ALGORYTMU:
    //  1) JAK TRAFIA NA ŚCIANE - IDZIE JEJ OBWODEM W DWIE STRONY, DOPÓKI NASTĘPNY KROK NIE BĘDZIE ŚCIANĄ,
    //      POTEM WYBIERA KRÓTSZA SCIEŻKĘ;          (Poki co idzie tylko w lewo, dorobic ruch prawostronny)
    //  2) ALGORYTM BAZUJE NA A*;
    //  3) NA KOŃCU MUSI PUNKTY GIĘCIA WYPLASZCZYĆ ZEBY UZYSKAĆ NAJKRÓTSZA ŚCIEŻKE IOK      (dodać takową opcję)

    paths->add_list();
    paths->add_list();

    DoubleList::list * possiblePath = paths->listHead, * second = paths->listHead->nextList, * forbiddenList = new DoubleList::list;

    DoubleList::list2d * checkpoints = new DoubleList::list2d;

    checkpoints->add_list();
    checkpoints->add_list();

    if (possiblePath->head == 0)
    {
        possiblePath->add_element(list2d->check_type(x1,y1,list2d),x1,y1);
    }

    if (second->head == 0)
    {
        second->add_element(list2d->check_type(x1,y1,list2d),x1,y1);
    }

    checkpoints->listHead->add_element(list2d->check_type(x1,y1,list2d),x1,y1);
    checkpoints->listTail->add_element(list2d->check_type(x1,y1,list2d),x1,y1);

    DoubleList::pathElement * element = possiblePath->head, * chosenElement, * successorElement,
            * forbiddenElement;

    possiblePath->tail->g = 0;
    possiblePath->tail->h = Algorithm::distance_between_points(x1,y1,x2,y2);
    possiblePath->tail->f = possiblePath->tail->g + possiblePath->tail->h;

    second->tail->g = 0;
    second->tail->h = Algorithm::distance_between_points(x1,y1,x2,y2);
    second->tail->f = second->tail->g + second->tail->h;

    int /*pathElementsTransfered = 0,*/ licznik = 0, wartoscF = element->f,
            formerF = element->h; // OD NIEGO ZALEZY CZY UZNA TRASE ZA ZŁĄ

    element->g = 0;
        element->h = Algorithm::distance_between_points(x1,y1,x2,y2);
        element->f = element->g + element->h;

        bool stop = false, rightWasWall = false, leftWasWall = false, rightIsWall = false, leftIsWall = false;

        int walls = 0;

        while (licznik < 500 && stop == false)   //BACKUPA ZROB
        {

            rightWasWall = rightIsWall;
            leftWasWall = leftIsWall;

            if (!(abs(x2-possiblePath->tail->x) <= radius - 1 && abs(y2-possiblePath->tail->y) <= radius - 1))
            {
                leftIsWall = build_path_element(possiblePath->tail->x,possiblePath->tail->y,x2,y2,radius,possiblePath,list2d, paths, 0);
                if (leftIsWall)
                    walls ++;
                if (leftWasWall == true && leftIsWall != true)
                {
                    checkpoints->listHead->add_element(possiblePath->tail->type, possiblePath->tail->x, possiblePath->tail->y);
                }
            }
            else
                stop = true;

            if (!(abs(x2-second->tail->x) <= radius - 1 && abs(y2-second->tail->y) <= radius - 1))
            {
                rightIsWall = build_path_element(second->tail->x,second->tail->y,x2,y2,radius,second,list2d, paths, 1);
                if (rightIsWall)
                    walls ++;
                if (rightWasWall == true && rightIsWall != true)
                {
                    checkpoints->listTail->add_element(second->tail->type, second->tail->x, second->tail->y);
                }
            }
            else
                stop = true;

            licznik ++;
        }

        checkpoints->listHead->add_element(list2d->check_type(x2,y2,list2d),x2,y2);
        checkpoints->listTail->add_element(list2d->check_type(x2,y2,list2d),x2,y2);

        qDebug() << "CHECKPOINTY LISTY PIERWSZEJ: ";
        checkpoints->listHead->show_list(checkpoints->listHead->counter);

        qDebug() << "CHECKPOINTY LISTY DRUGIEJ: ";
        checkpoints->listTail->show_list(checkpoints->listTail->counter);

        DoubleList::list2d * paths2 = new DoubleList::list2d;

        DoubleList::pathElement * tracer = new DoubleList::pathElement;


        /// TRZEBA ZROBIC NAJKROTSZE SCIEZKI W SCIEZCE, OD POCZATKU SPRAWDZA CZY BEDZIE SCIANA W NAJKROTSZEJ SCIEZCE DO KAZDEGO
        /// DAJ WARUNEK NA SCIANE< WTEDY BEDZIE SIE ODPALAC TO CO NIZEJ - POSORTOWANIE SCIEZKI

        /* if (walls > 0)
        {
            DoubleList::pathElement * finish = new DoubleList::pathElement, * start = new DoubleList::pathElement,
                                * sortedPathElement = new DoubleList::pathElement;
            DoubleList::list2d * theUltimatePath = new DoubleList::list2d;
            bool wall = false;

            start = possiblePath->tail;
            finish = possiblePath->head;

            while (finish != start)
            {
                DoubleList::list * sortingPath = new DoubleList::list;

                wall = false;

                sortingPath->add_element(start->type, start->x, start->y);

                /// TU MA BYC FUNKCJA PROSTUJACA SCIEZKE
                ///

            }

            delete finish;

            return theUltimatePath;
        }   */


        /*paths2->add_list();
        paths2->add_list();

        paths2->listHead->add_element(list2d->check_type(x1,y1,list2d),x1,y1);
        paths2->listTail->add_element(checkpoints->listTail->head->type, checkpoints->listTail->head->x, checkpoints->listTail->head->y);

        if ((possiblePath->tail->x == x2 && possiblePath->tail->y == y2) && checkpoints->listHead->counter > 2)
        {
            tracer = checkpoints->listHead->head->next;
            while (tracer != 0)
            {
                while (!(paths2->listHead->tail->x == tracer->x && paths2->listHead->tail->y == tracer->y))
                {
                    leftIsWall = build_path_element(paths2->listHead->tail->x, paths2->listHead->tail->y, tracer->x, tracer->y, radius, paths2->listHead, list2d, paths2, 0);
                }
                tracer = tracer->next;
            }

            delete tracer;

            return paths2;
        }

        if ((second->tail->x == x2 && second->tail->y == y2) && checkpoints->listTail->counter > 2)
        {

            tracer = checkpoints->listTail->head->next;
            while (tracer != 0)
            {
                while (!(paths2->listTail->tail->x == tracer->x && paths2->listTail->tail->y == tracer->y))
                {
                    leftIsWall = build_path_element(paths2->listTail->tail->x, paths2->listTail->tail->y, tracer->x, tracer->y, radius, paths2->listTail, list2d, paths2, 1);
                }
                tracer = tracer->next;
            }

            delete tracer;

            return paths2;

        }

        /*if (checkpoints->listHead->counter > 2 || checkpoints->listTail->counter > 2)
        {
            DoubleList::pathElement * tracer = new DoubleList::pathElement;

            tracer = checkpoints->listHead->head;

            possiblePath = paths2->listHead;
            while (tracer != 0)
            {
                while (!(paths2->listHead->tail->x == tracer->x && paths2->listHead->tail->y == tracer->y))
                {
                    leftIsWall = build_path_element(possiblePath->tail->x,possiblePath->tail->y,tracer->x,tracer->y,radius,possiblePath,list2d, paths2, 0);
                }
                tracer = tracer->next;
            }

            tracer = checkpoints->listTail->head;
            possiblePath = paths2->listTail;
            while (tracer != 0)
            {
                while (!(paths2->listTail->tail->x == tracer->x && paths2->listTail->tail->y == tracer->y))
                {
                    leftIsWall = build_path_element(possiblePath->tail->x,possiblePath->tail->y,tracer->x,tracer->y,radius,possiblePath,list2d, paths2, 0);
                }
                tracer = tracer->next;
            }

            delete tracer;

            return paths2;
        }   */

    return paths;

}
