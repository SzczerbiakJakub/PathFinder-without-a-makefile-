var namespaces_dup =
[
    [ "std", "namespacestd.html", null ],
    [ "Ui", "namespace_ui.html", null ]
];