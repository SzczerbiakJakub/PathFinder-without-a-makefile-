var struct_double_list_1_1list =
[
    [ "list", "struct_double_list_1_1list.html#a2aa2caf317d95e33c76edc107adbe9db", null ],
    [ "add_element", "struct_double_list_1_1list.html#a8b1ec71e76b4a99d9e7dd166649d0c3f", null ],
    [ "remove_last_element", "struct_double_list_1_1list.html#a63e8662edf8b475d4171c14050b48d61", null ],
    [ "show_list", "struct_double_list_1_1list.html#ae97b6d070baa019da7f1c91c1b19c000", null ],
    [ "counter", "struct_double_list_1_1list.html#aacaddb081fbb1dc7c64bb503fc3daece", null ],
    [ "head", "struct_double_list_1_1list.html#a1ea6a430c7be39e0dc79417a2aab8a72", null ],
    [ "nextList", "struct_double_list_1_1list.html#ac4d016f12d1d940f649e6d4ac31602f3", null ],
    [ "prevList", "struct_double_list_1_1list.html#a4a4cc88e253c1cc36d4597ae5aee490b", null ],
    [ "tail", "struct_double_list_1_1list.html#a6686bbea0e483bbf204ccff8b7ded14c", null ]
];