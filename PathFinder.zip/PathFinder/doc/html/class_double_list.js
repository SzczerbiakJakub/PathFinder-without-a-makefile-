var class_double_list =
[
    [ "list", "struct_double_list_1_1list.html", "struct_double_list_1_1list" ],
    [ "list2d", "struct_double_list_1_1list2d.html", "struct_double_list_1_1list2d" ],
    [ "pathElement", "struct_double_list_1_1path_element.html", "struct_double_list_1_1path_element" ]
];