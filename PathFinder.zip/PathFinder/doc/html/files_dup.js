var files_dup =
[
    [ "algorithm.cpp", "algorithm_8cpp.html", null ],
    [ "algorithm.h", "algorithm_8h.html", "algorithm_8h" ],
    [ "list.cpp", "list_8cpp.html", null ],
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ]
];