var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "blueDot", "class_main_window.html#afb7ae78afa1de26a635a1d60091cc971", null ],
    [ "get_path_element", "class_main_window.html#a9e767f86d80203ee461b11dd837748e1", null ],
    [ "get_point_a_X", "class_main_window.html#afbaec4387138f7faeb36cae9aac12db9", null ],
    [ "get_point_a_Y", "class_main_window.html#aded79073cd49777966145ff20a8ca5f8", null ],
    [ "get_point_b_X", "class_main_window.html#ad26a13bece7f7b64798871a63d33c2b5", null ],
    [ "get_point_b_Y", "class_main_window.html#a845b38b1d109350abb3df81dfc9b61e5", null ],
    [ "loadMap", "class_main_window.html#a6509f037a3ae039203f2b8de2cd5b631", null ],
    [ "pathImage", "class_main_window.html#a99b0171f8a95aab5623eb3777b7ab0b2", null ],
    [ "redDot", "class_main_window.html#ac3a1f54a0319493c152ff8144f0fb72d", null ],
    [ "search_for_path", "class_main_window.html#aba837ecae1a5cda0f0006b71a4ac407f", null ],
    [ "fileName", "class_main_window.html#a06968aebc42a16ab51c5888b4784075d", null ],
    [ "lista2d", "class_main_window.html#a0df1c8bff170c9f168667612988fad97", null ],
    [ "mapLoaded", "class_main_window.html#a197cf41aa35ffd61806c7f1deb4742d3", null ],
    [ "pm", "class_main_window.html#a0a5e9f0fcc81aca3f277759949b73761", null ],
    [ "wrongPointA", "class_main_window.html#a149a804cb0db2e0dac9d1620e479dee4", null ],
    [ "wrongPointB", "class_main_window.html#a3725a94fee6a121fec4b8939b6ab583b", null ]
];