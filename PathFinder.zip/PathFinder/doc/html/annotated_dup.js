var annotated_dup =
[
    [ "Algorithm", "class_algorithm.html", "class_algorithm" ],
    [ "DoubleList", "class_double_list.html", "class_double_list" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ]
];