var hierarchy =
[
    [ "Algorithm", "class_algorithm.html", null ],
    [ "DoubleList", "class_double_list.html", null ],
    [ "DoubleList::list", "struct_double_list_1_1list.html", null ],
    [ "DoubleList::list2d", "struct_double_list_1_1list2d.html", null ],
    [ "DoubleList::pathElement", "struct_double_list_1_1path_element.html", null ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];