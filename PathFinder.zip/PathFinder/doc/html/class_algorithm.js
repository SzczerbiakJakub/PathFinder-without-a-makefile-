var class_algorithm =
[
    [ "Algorithm", "class_algorithm.html#a472bdce2086324f49da7794e27ccaa54", null ],
    [ "pathImage", "class_algorithm.html#ad18576203d5583ea04ac1f4f5d385bed", null ]
];