var searchData=
[
  ['bluedot_0',['blueDot',['../class_main_window.html#afb7ae78afa1de26a635a1d60091cc971',1,'MainWindow']]]
];
