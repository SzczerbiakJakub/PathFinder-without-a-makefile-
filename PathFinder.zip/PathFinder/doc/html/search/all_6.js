var searchData=
[
  ['h_0',['h',['../struct_double_list_1_1path_element.html#a1f9023664f42bb79431d1e044ee106af',1,'DoubleList::pathElement']]],
  ['head_1',['head',['../struct_double_list_1_1list.html#a1ea6a430c7be39e0dc79417a2aab8a72',1,'DoubleList::list']]]
];
