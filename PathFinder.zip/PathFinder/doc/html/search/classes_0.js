var searchData=
[
  ['algorithm_0',['Algorithm',['../class_algorithm.html',1,'']]]
];
