var searchData=
[
  ['next_0',['next',['../struct_double_list_1_1path_element.html#a50862a8b1f078a9daf71802b9e20c924',1,'DoubleList::pathElement']]],
  ['nextlist_1',['nextList',['../struct_double_list_1_1list.html#ac4d016f12d1d940f649e6d4ac31602f3',1,'DoubleList::list']]]
];
