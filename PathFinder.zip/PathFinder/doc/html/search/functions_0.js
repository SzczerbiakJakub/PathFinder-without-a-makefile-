var searchData=
[
  ['add_5felement_0',['add_element',['../struct_double_list_1_1list.html#a8b1ec71e76b4a99d9e7dd166649d0c3f',1,'DoubleList::list']]],
  ['add_5flist_1',['add_list',['../struct_double_list_1_1list2d.html#a87f0c55db26153ee0ac5991fe841b3ec',1,'DoubleList::list2d']]],
  ['algorithm_2',['Algorithm',['../class_algorithm.html#a472bdce2086324f49da7794e27ccaa54',1,'Algorithm']]]
];
