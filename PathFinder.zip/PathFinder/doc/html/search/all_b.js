var searchData=
[
  ['reddot_0',['redDot',['../class_main_window.html#ac3a1f54a0319493c152ff8144f0fb72d',1,'MainWindow']]],
  ['remove_5flast_5felement_1',['remove_last_element',['../struct_double_list_1_1list.html#a63e8662edf8b475d4171c14050b48d61',1,'DoubleList::list']]],
  ['remove_5flist_2',['remove_list',['../struct_double_list_1_1list2d.html#aef3f75dda6e85bb0159199f069fff9cc',1,'DoubleList::list2d']]]
];
