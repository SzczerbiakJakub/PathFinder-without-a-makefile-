var searchData=
[
  ['nearest_5fspace_5fclockwise_0',['nearest_space_clockwise',['../class_algorithm.html#aa19c8f6cc35a764117608b247f193c3e',1,'Algorithm']]]
];
