var searchData=
[
  ['x_0',['x',['../struct_double_list_1_1path_element.html#adbdcb5abc5cad112ece73a2fdd7f635e',1,'DoubleList::pathElement']]]
];
