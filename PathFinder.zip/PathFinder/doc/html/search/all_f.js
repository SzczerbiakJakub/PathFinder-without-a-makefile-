var searchData=
[
  ['wrongpointa_0',['wrongPointA',['../class_main_window.html#a149a804cb0db2e0dac9d1620e479dee4',1,'MainWindow']]],
  ['wrongpointb_1',['wrongPointB',['../class_main_window.html#a3725a94fee6a121fec4b8939b6ab583b',1,'MainWindow']]]
];
