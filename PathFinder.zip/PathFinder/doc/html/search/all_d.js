var searchData=
[
  ['tail_0',['tail',['../struct_double_list_1_1list.html#a6686bbea0e483bbf204ccff8b7ded14c',1,'DoubleList::list']]],
  ['type_1',['type',['../struct_double_list_1_1path_element.html#a8c5ecbf3b02cf9da4f67e02988c799a9',1,'DoubleList::pathElement']]]
];
