var searchData=
[
  ['counter_0',['counter',['../struct_double_list_1_1list.html#aacaddb081fbb1dc7c64bb503fc3daece',1,'DoubleList::list']]],
  ['currentlist_1',['currentList',['../struct_double_list_1_1list2d.html#a2c9d57f4af89088dc4301330d2c90254',1,'DoubleList::list2d']]]
];
