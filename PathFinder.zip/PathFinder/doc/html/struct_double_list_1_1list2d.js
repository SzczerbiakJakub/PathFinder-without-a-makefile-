var struct_double_list_1_1list2d =
[
    [ "list2d", "struct_double_list_1_1list2d.html#af85969601ca8e35760f4d76af592330b", null ],
    [ "add_list", "struct_double_list_1_1list2d.html#a87f0c55db26153ee0ac5991fe841b3ec", null ],
    [ "check_type", "struct_double_list_1_1list2d.html#a75a6ed40a9746da894160da5f7f9cd1e", null ],
    [ "create_lists", "struct_double_list_1_1list2d.html#a198f9ba827d454c3ce62cf3bc37f6f3f", null ],
    [ "remove_list", "struct_double_list_1_1list2d.html#aef3f75dda6e85bb0159199f069fff9cc", null ],
    [ "show_all", "struct_double_list_1_1list2d.html#a9d36e46c48acea48ba08b1f75907b826", null ],
    [ "show_list_2d", "struct_double_list_1_1list2d.html#ae5bd0e6084abd5e4428907dab9cef2a8", null ],
    [ "currentList", "struct_double_list_1_1list2d.html#a2c9d57f4af89088dc4301330d2c90254", null ],
    [ "listCounter", "struct_double_list_1_1list2d.html#a21741175cd3d8622caeb073dfa26f5b4", null ],
    [ "listHead", "struct_double_list_1_1list2d.html#a86e133db28fa0ee225fad244db39fd7b", null ],
    [ "listTail", "struct_double_list_1_1list2d.html#a24cd849230d8ccba11b00b089783ab8c", null ]
];