/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *loadFile;
    QPushButton *close;
    QLabel *label;
    QLabel *label_2;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QTextEdit *textEdit_3;
    QVBoxLayout *verticalLayout_2;
    QTextEdit *textEdit_4;
    QTextEdit *textEdit_5;
    QVBoxLayout *verticalLayout_3;
    QTextEdit *textEdit_6;
    QTextEdit *textEdit_7;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit_2;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QLabel *map;
    QLabel *map_name;
    QLabel *point_a;
    QLabel *point_b;
    QLineEdit *point_b_coords;
    QLineEdit *point_a_coords;
    QPushButton *distance;
    QPushButton *show_path;
    QLabel *path;
    QPushButton *search_for_path;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(600, 620);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        loadFile = new QPushButton(centralwidget);
        loadFile->setObjectName(QString::fromUtf8("loadFile"));
        loadFile->setEnabled(true);
        loadFile->setGeometry(QRect(53, 1, 80, 50));
        loadFile->setCursor(QCursor(Qt::PointingHandCursor));
        loadFile->setAutoFillBackground(false);
        close = new QPushButton(centralwidget);
        close->setObjectName(QString::fromUtf8("close"));
        close->setGeometry(QRect(1, 1, 50, 50));
        close->setCursor(QCursor(Qt::PointingHandCursor));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(270, 0, 115, 16));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(400, 0, 115, 16));
        horizontalLayoutWidget = new QWidget(centralwidget);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(520, 10, 306, 150));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        textEdit_3 = new QTextEdit(horizontalLayoutWidget);
        textEdit_3->setObjectName(QString::fromUtf8("textEdit_3"));

        horizontalLayout->addWidget(textEdit_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        textEdit_4 = new QTextEdit(horizontalLayoutWidget);
        textEdit_4->setObjectName(QString::fromUtf8("textEdit_4"));
        textEdit_4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_4->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_2->addWidget(textEdit_4);

        textEdit_5 = new QTextEdit(horizontalLayoutWidget);
        textEdit_5->setObjectName(QString::fromUtf8("textEdit_5"));
        textEdit_5->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_5->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_5->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        textEdit_5->setTabChangesFocus(false);
        textEdit_5->setReadOnly(true);

        verticalLayout_2->addWidget(textEdit_5);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        textEdit_6 = new QTextEdit(horizontalLayoutWidget);
        textEdit_6->setObjectName(QString::fromUtf8("textEdit_6"));
        textEdit_6->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_6->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout_3->addWidget(textEdit_6);

        textEdit_7 = new QTextEdit(horizontalLayoutWidget);
        textEdit_7->setObjectName(QString::fromUtf8("textEdit_7"));
        textEdit_7->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_7->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_7->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        textEdit_7->setTabChangesFocus(false);
        textEdit_7->setReadOnly(true);

        verticalLayout_3->addWidget(textEdit_7);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        textEdit_2 = new QTextEdit(horizontalLayoutWidget);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

        verticalLayout->addWidget(textEdit_2);

        textEdit = new QTextEdit(horizontalLayoutWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        textEdit->setTabChangesFocus(false);
        textEdit->setReadOnly(true);

        verticalLayout->addWidget(textEdit);


        horizontalLayout->addLayout(verticalLayout);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(520, 160, 80, 21));
        map = new QLabel(centralwidget);
        map->setObjectName(QString::fromUtf8("map"));
        map->setGeometry(QRect(1, 53, 512, 512));
        map_name = new QLabel(centralwidget);
        map_name->setObjectName(QString::fromUtf8("map_name"));
        map_name->setGeometry(QRect(1, 566, 512, 16));
        map_name->setAlignment(Qt::AlignCenter);
        point_a = new QLabel(centralwidget);
        point_a->setObjectName(QString::fromUtf8("point_a"));
        point_a->setGeometry(QRect(200, 30, 1, 1));
        point_b = new QLabel(centralwidget);
        point_b->setObjectName(QString::fromUtf8("point_b"));
        point_b->setGeometry(QRect(200, 20, 1, 1));
        point_b_coords = new QLineEdit(centralwidget);
        point_b_coords->setObjectName(QString::fromUtf8("point_b_coords"));
        point_b_coords->setGeometry(QRect(410, 20, 91, 21));
        point_b_coords->setAlignment(Qt::AlignCenter);
        point_a_coords = new QLineEdit(centralwidget);
        point_a_coords->setObjectName(QString::fromUtf8("point_a_coords"));
        point_a_coords->setGeometry(QRect(280, 20, 91, 21));
        point_a_coords->setAlignment(Qt::AlignCenter);
        distance = new QPushButton(centralwidget);
        distance->setObjectName(QString::fromUtf8("distance"));
        distance->setGeometry(QRect(520, 190, 80, 21));
        show_path = new QPushButton(centralwidget);
        show_path->setObjectName(QString::fromUtf8("show_path"));
        show_path->setGeometry(QRect(520, 250, 80, 21));
        path = new QLabel(centralwidget);
        path->setObjectName(QString::fromUtf8("path"));
        path->setGeometry(QRect(1, 53, 512, 512));
        search_for_path = new QPushButton(centralwidget);
        search_for_path->setObjectName(QString::fromUtf8("search_for_path"));
        search_for_path->setGeometry(QRect(520, 220, 80, 21));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 600, 20));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "PathFinder", nullptr));
        loadFile->setText(QCoreApplication::translate("MainWindow", "Wczytaj map\304\231", nullptr));
        close->setText(QCoreApplication::translate("MainWindow", "Wyjd\305\272", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Wsp\303\263\305\202rz\304\231dne punktu A", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Wsp\303\263\305\202rz\304\231dne punktu B", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "PushButton", nullptr));
        map->setText(QString());
        map_name->setText(QString());
        point_a->setText(QString());
        point_b->setText(QString());
        point_b_coords->setText(QCoreApplication::translate("MainWindow", "0,0", nullptr));
        point_a_coords->setText(QCoreApplication::translate("MainWindow", "0,0", nullptr));
        distance->setText(QCoreApplication::translate("MainWindow", "Distance", nullptr));
        show_path->setText(QCoreApplication::translate("MainWindow", "Show path", nullptr));
        path->setText(QString());
        search_for_path->setText(QCoreApplication::translate("MainWindow", "Search for path", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
